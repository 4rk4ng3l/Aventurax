/**
 * Created by Administrator on 9/27/2016.
 */
var locale_daterangepicker = {
    direction: 'ltr',
    applyLabel: 'Apply',
    cancelLabel: 'Cancel',
    fromLabel: 'From',
    toLabel: 'To',
    customRangeLabel: 'Custom',
    daysOfWeek: ['Sun', 'Mo', 'Tu', 'We', 'Th', 'Fr','Sa'],
    monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    firstDay: 1,
    today: 'Today'
};