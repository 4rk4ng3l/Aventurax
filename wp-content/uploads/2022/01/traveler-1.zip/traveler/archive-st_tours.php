<?php
/**
 * Created by PhpStorm.
 * User: me664
 * Date: 3/17/15
 * Time: 6:45 PM
 */
get_template_part('search-tour');